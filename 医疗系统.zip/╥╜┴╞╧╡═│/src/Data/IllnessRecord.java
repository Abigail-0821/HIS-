package Data;

import java.util.List;

public class IllnessRecord {
    private String 主诉;
    private String 现病史;
    private String 现病治疗情况;
    private String 既往史;
    private String 过敏史;
    private String 体格检查;
    private String 检查建议;
    private String 注意事项;

    public String get主诉() {
        return 主诉;
    }

    public void set主诉(String 主诉) {
        this.主诉 = 主诉;
    }

    public String get现病史() {
        return 现病史;
    }

    public void set现病史(String 现病史) {
        this.现病史 = 现病史;
    }

    public String get现病治疗情况() {
        return 现病治疗情况;
    }

    public void set现病治疗情况(String 现病治疗情况) {
        this.现病治疗情况 = 现病治疗情况;
    }

    public String get既往史() {
        return 既往史;
    }

    public void set既往史(String 既往史) {
        this.既往史 = 既往史;
    }

    public String get过敏史() {
        return 过敏史;
    }

    public void set过敏史(String 过敏史) {
        this.过敏史 = 过敏史;
    }

    public String get体格检查() {
        return 体格检查;
    }

    public void set体格检查(String 体格检查) {
        this.体格检查 = 体格检查;
    }

    public String get检查建议() {
        return 检查建议;
    }

    public void set检查建议(String 检查建议) {
        this.检查建议 = 检查建议;
    }

    public String get注意事项() {
        return 注意事项;
    }

    public void set注意事项(String 注意事项) {
        this.注意事项 = 注意事项;
    }
}
