package Data;

import java.util.ArrayList;
import java.util.List;

public class MedicineRecord {
    private String name;
    private List<Medicine> medicines = new ArrayList<>();

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setMedicines(List<Medicine> medicines) {
        this.medicines = medicines;
    }

    @Override
    public String toString() {
        return name;
    }

    public List<Medicine> getMedicines() {
        return medicines;
    }
}
