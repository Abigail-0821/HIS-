package Data;

public class Hospital {
    private Department department;
}
