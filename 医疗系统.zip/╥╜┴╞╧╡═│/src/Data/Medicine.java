package Data;

public class Medicine {
    private String chname;//名字
    private String form;
    private int medicineId;//编号
    private String name;
    private int price;//价格
    private String type;
    int number; //数量
    String functions; //功效


    public Medicine() {
    }

    public String getChname() {
        return chname;
    }

    public void setChname(String chname) {
        this.chname = chname;
    }

    public String getForm() {
        return form;
    }

    public void setForm(String form) {
        this.form = form;
    }

    public int getMedicineId() {
        return medicineId;
    }

    public void setMedicineId(int medicineId) {
        this.medicineId = medicineId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Medicine(String chname, String form, int medicineId, String name, int price, String type) {
        this.chname = chname;
        this.form = form;
        this.medicineId = medicineId;
        this.name = name;
        this.price = price;
        this.type = type;
    }
}
