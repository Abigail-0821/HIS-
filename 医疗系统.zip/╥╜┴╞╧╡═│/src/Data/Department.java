package Data;

public class Department {
    private DoctorList doctorList;
}
