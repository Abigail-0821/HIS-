package Data;

import java.util.Date;

public class Patient{
    private String name;
    private String id;
    private String sex;
    private int age;
    private String mediId;
    private Date birthday;
    private String address;
    private IllnessRecord illnessRecord;
    private MedicineRecord medicineRecord;
    private boolean treat;

    public boolean isTreat() {
        return treat;
    }

    public void setTreat(boolean treat) {
        this.treat = treat;
    }

    public Patient() {
    }

    public Patient(String name, String id, String sex, int age, String mediId, String address, IllnessRecord illnessRecord, MedicineRecord medicineRecord) {
        this.name = name;
        this.id = id;
        this.sex = sex;
        this.age = age;
        this.mediId = mediId;
        this.address = address;
        this.illnessRecord = illnessRecord;
        this.medicineRecord = medicineRecord;
    }

    public Patient(String name, String id, String sex, int age, String mediId, String address) {
        this.name = name;
        this.id = id;
        this.sex = sex;
        this.age = age;
        this.mediId = mediId;
        this.address = address;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getMediId() {
        return mediId;
    }

    public void setMediId(String mediId) {
        this.mediId = mediId;
    }

    public IllnessRecord getIllnessRecord() {
        return illnessRecord;
    }

    public void setIllnessRecord(IllnessRecord illnessRecord) {
        this.illnessRecord = illnessRecord;
    }

    public MedicineRecord getMedicineRecord() {
        return medicineRecord;
    }

    public void setMedicineRecord(MedicineRecord medicineRecord) {
        this.medicineRecord = medicineRecord;
    }

    @Override
    public String toString() {
        return  id + "   " + name + "   " + age + "   " + sex;
    }

    public Patient(String name, String id, String sex, int age, Date birthday) {
        this.name = name;
        this.id = id;
        this.sex = sex;
        this.age = age;
        this.birthday = birthday;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }


}
