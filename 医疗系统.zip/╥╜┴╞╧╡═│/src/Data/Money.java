package Data;

public class Money {
}
