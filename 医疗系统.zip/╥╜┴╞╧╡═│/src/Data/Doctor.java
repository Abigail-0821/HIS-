package Data;

import java.io.Serializable;

public class Doctor implements Serializable {
    private PatientList pl;
    private String name ;
    private int number;
    private String keshi;
    private String password;
    private String numberkind;

    public Doctor() {
    }

    public Doctor(PatientList pl, String name, int number, String keshi, String password, String numberkind) {
        this.pl = pl;
        this.name = name;
        this.number = number;
        this.keshi = keshi;
        this.password = password;
        this.numberkind = numberkind;
    }

    public String getNumberkind() {
        return numberkind;
    }

    public void setNumberkind(String numberkind) {
        this.numberkind = numberkind;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getKeshi() {
        return keshi;
    }

    public void setKeshi(String keshi) {
        this.keshi = keshi;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public PatientList getPl() {
        return pl;
    }

    public void setPl(PatientList pl) {
        this.pl = pl;
    }

}
