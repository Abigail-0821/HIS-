package Data;

import com.alibaba.fastjson.JSON;

import java.io.*;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DoctorList {
   private List<Doctor> dl = new ArrayList<>();

    public List<Doctor> getDl() {
        return dl;
    }
}
