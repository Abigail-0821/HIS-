package Data;

import java.util.Vector;

//所有病人的就诊记录及病例
class Records{
    String patientID; //患者ID
    String time; //患者就诊时间，患者ID和就诊时间可以确定一条就诊记录
    String doctorID; //医生ID
    String memo;//其他医生写的病历之类
    Vector<String> medicines;//所用药品
}

