package Data;

import java.util.ArrayList;
import java.util.List;

public class MedicineTemplate {
    private List<Medicine> dl = new ArrayList<>();

    public List<Medicine> getDl() {
        return dl;
    }
}
