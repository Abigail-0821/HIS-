package Data;

public class Ghy {
    static private String name = "ghy";
    static private String password = "ghy123";

    public static String getName() {
        return name;
    }

    public static String getPassword() {
        return password;
    }

    public Ghy() {
    }
}
