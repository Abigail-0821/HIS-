package Data;

public class Fzy {
    static private String name = "fzy";
    static private String password = "fzy123";

    public static String getName() {
        return name;
    }

    public static String getPassword() {
        return password;
    }

    public Fzy() {
    }
}
