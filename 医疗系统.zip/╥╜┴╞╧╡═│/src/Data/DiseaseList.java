package Data;

import java.util.ArrayList;
import java.util.List;

public class DiseaseList {
    private List<DiseaseType> dl = new ArrayList<>();

    public List<DiseaseType> getDl() {
        return dl;
    }
}
