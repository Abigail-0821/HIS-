package Data;

import java.util.Vector;

public class DiseaseType {
    private String ICDNumber; // 编号
    private String name;//名字
    private String ParentID; //上一级病的ID
    private Vector<DiseaseType> sub_diseases; //存储该病种下的子病种类型
    private Vector<String> patients;//存储得有该病的所有患者ID

    public String getParentID() {
        return ParentID;
    }

    public void setParentID(String parentID) {
        ParentID = parentID;
    }

    public Vector<DiseaseType> getSub_diseases() {
        return sub_diseases;
    }

    public void setSub_diseases(Vector<DiseaseType> sub_diseases) {
        this.sub_diseases = sub_diseases;
    }

    public Vector<String> getPatients() {
        return patients;
    }

    public void setPatients(Vector<String> patients) {
        this.patients = patients;
    }

    public String getICDNumber() {
        return ICDNumber;
    }

    public void setICDNumber(String ICDNumber) {
        this.ICDNumber = ICDNumber;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public DiseaseType() {
    }

    public DiseaseType(String name) {
        this.name = name;
    }
}
