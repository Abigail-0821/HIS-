package View;

import Data.Doctor;
import Data.Medicine;
import Data.Patient;
import Department.ReadFile;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class PayInformController extends ReadFile implements Initializable {
    @FXML
    private Button 暂存1;

    @FXML
    private TextField 姓名;

    @FXML
    private TextField 病历号;

    @FXML
    private TextField 应收金额;

    @FXML
    private TextField 实收;

    @FXML
    private TextField a找零;

    @FXML
    private TextField 发票号;

    @FXML
    private Button 暂存;

    @FXML
    private ComboBox<String> 支付方式;

    private int actual;

    Patient pp = new Patient();

    void getPa(Patient p){
        pp = p;
        show();
    }

    private void show() {
        姓名.setText(pp.getName());
        病历号.setText(pp.getMediId());
        发票号.setText("0000");
        payway();
        应收金额.setText(calculate() + "");
    }

    private void addListenner() {
        实收.textProperty().addListener(new NoticeListItemChangeListener());
    }

    private class NoticeListItemChangeListener implements ChangeListener<Object> {
        @Override
        public void changed(ObservableValue<?> observable, Object oldValue, Object newValue) {
            if (!newValue.toString().equals("")){
            actual = Integer.parseInt(newValue.toString());
            a找零.setText((actual - calculate()) + "");
            }else{
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("收费提示");
                alert.setContentText("请输入实收金额");
                alert.showAndWait();//提示
            }
        }
    }


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        addListenner();
        show();
    }

    private void payway() {
        ObservableList<String> choices = FXCollections.observableArrayList("现金", "银行卡");
        支付方式.setItems(choices);
    }

    private int calculate() {
        int allprice = 0;
        for ( Medicine m : getMedicineList1() ) {
            allprice = allprice + m.getPrice();
        }
        return allprice;
    }

    @FXML
    void pay(){
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("收费提示");
        alert.setContentText("收费成功");
        alert.showAndWait();//提示
        Stage stage = (Stage) 暂存.getScene().getWindow();
        stage.close();
    }

    @FXML
    void quit(){
        Stage stage = (Stage) 暂存1.getScene().getWindow();
        stage.close();
    }
}

