package View;

import Data.Medicine;
import Data.MedicineRecord;
import Data.Patient;
import Data.PatientList;
import Department.Pay;
import Department.ReadFile;
import Department.Save;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class PayController extends ReadFile {
    @FXML
    private TextField Address;

    @FXML
    private TableColumn<?, ?> dj;

    @FXML
    private TableView<Patient> hzz;

    @FXML
    private TableColumn<?, ?> blhhh;

    @FXML
    private Button 搜索;

    @FXML
    private TableColumn<?, ?> xmmm;

    @FXML
    private Button 暂存1;

    @FXML
    private TextField 姓名;

    @FXML
    private TextField 病历号;

    @FXML
    private TableColumn<?, ?> xm;

    @FXML
    private TableColumn<?, ?> gg;

    @FXML
    private TableColumn<?, ?> bm;

    @FXML
    private TextField id;

    @FXML
    private TableView<Medicine> xmmmmm;

    public String get姓名() {
        return 姓名.getText();
    }

    private PatientList pl = getPatient();
    private Patient patient = new Patient();
    Save s = new Save();


    public void searchPatient(String d) {
        boolean isfound = false;
        if (!pl.getPatientList().isEmpty()) {
            for ( Patient p : pl.getPatientList() ) {
                if (p.getMediId().equals(d)) {
                    isfound = true;
                    patient = p;
                    show(p);
                }
            }
        }
        if(!isfound){
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("缴费提示");
            alert.setContentText("无此患者");
            alert.show();
        }
    }

    @FXML
    void search(){
        searchPatient(病历号.getText());
    }
    private void show(Patient p){
        //显示患者
        姓名.setText(p.getName());
        id.setText(p.getId());
        Address.setText(p.getAddress());

        //在列表中显示患者
        ObservableList<Patient> patients = FXCollections.observableArrayList();
        patients.add(p);
        xmmm.setCellValueFactory(new PropertyValueFactory<>("name"));
        blhhh.setCellValueFactory(new PropertyValueFactory<>("mediId"));
        hzz.setItems(patients);

        //在列表中显示患者所开药方
        ObservableList<Medicine> medicine = FXCollections.observableArrayList();
        medicine.addAll(getMedicineList1());
        xm.setCellValueFactory(new PropertyValueFactory<>("chname"));
        dj.setCellValueFactory(new PropertyValueFactory<>("price"));
        bm.setCellValueFactory(new PropertyValueFactory<>("medicineId"));
        gg.setCellValueFactory(new PropertyValueFactory<>("type"));
        xmmmmm.setItems(medicine);
    }

    @FXML
    void pay(){
        Parent in = null;
        FXMLLoader loader = new FXMLLoader();
        try {
            loader.setLocation(getClass().getResource("/View/PayInform.fxml"));
            in = loader.load();

            PayInformController pic = loader.getController();
            pic.getPa(patient);

            Stage newStage = new Stage();
            newStage.setScene(new Scene(in,779,462));
            newStage.setTitle("东软云HIS系统");

            newStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
