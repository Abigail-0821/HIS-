package View;

import javafx.fxml.FXML;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

import static javafx.fxml.FXMLLoader.load;

public class FzyController {

    @FXML
    private Button 退出;


    @FXML
    void out(){
        Stage sign = (Stage) 退出.getScene().getWindow();
        Parent in = null;
        try {
            in = load(getClass().getResource("/View/Login.fxml"));
            Scene scene = new Scene(in, 986, 640);
            sign.setScene(scene);
            sign.show();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
