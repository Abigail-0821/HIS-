package View;

import Data.Doctor;
import Data.Medicine;
import Data.Patient;
import Data.PatientList;
import Department.ReadFile;
import Department.Save;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.util.Callback;

import java.io.FileReader;
import java.util.List;

public class WithdrawController extends ReadFile {
    @FXML
    private Button 暂存1;

    @FXML
    private TextField 姓名;

    @FXML
    private TextField 病历号;

    @FXML
    private TextField Address;

    @FXML
    private TableColumn<?, ?> sfzh;

    @FXML
    private TableColumn<?, ?> xm;

    @FXML
    private TableColumn<?, ?> dz;

    @FXML
    private Button 搜索;

    @FXML
    private TextField id;

    @FXML
    private TableColumn<?, ?> kzzt;

    @FXML
    private TableColumn<?, ?> blh;

    @FXML
    private TableView<Patient> table11;


    private Patient pa;
    private PatientList pl = getPatient();
    Save s = new Save();

    public void searchPatient(String d) {
        boolean isfound = false;
        if (!pl.getPatientList().isEmpty()) {
            for ( Patient p : pl.getPatientList() ) {
                if (p.getMediId().equals(d)) {
                    isfound = true;
                    pa = p;
                    show(pa);
                }
            }
        }
        if(!isfound){
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("退号提示");
            alert.setContentText("无此患者");
            alert.show();
        }
    }

    @FXML
    void search(){
        searchPatient(病历号.getText());

    }
    private void show(Patient p){
        姓名.setText(p.getName());
        id.setText(p.getId());
        Address.setText(p.getAddress());
        p.setTreat(false);

        ObservableList<Patient> patients = FXCollections.observableArrayList();
        patients.add(p);

        blh.setCellValueFactory(new PropertyValueFactory<>("mediId"));
        xm.setCellValueFactory(new PropertyValueFactory<>("name"));
        sfzh.setCellValueFactory(new PropertyValueFactory<>("id"));
        dz.setCellValueFactory(new PropertyValueFactory<>("address"));
        kzzt.setCellValueFactory(new PropertyValueFactory<>("treat"));

//        cz.setCellFactory((col) -> {
//            TableCell<?, ?> cell = new TableCell<Patient, String>() {
//                @Override
//                public void updateItem(String item, boolean empty) {
//                    super.updateItem(item, empty);
//                    this.setText(null);
//                    this.setGraphic(null);
//
//                    if (!empty) {
//                        ImageView delICON = new ImageView(getClass().getResource("delete.png").toString());
//                        Button delBtn = new Button("删除", delICON);
//                        this.setGraphic(delBtn);
//                        delBtn.setOnMouseClicked((me) -> {
//                        });
//                    }
//                }
//
//            };
//            return cell;
//        });

//        Callback<TableColumn<<cap\?, ?>, TableCell<?, ?>> DcellFactory
//                = new Callback<TableColumn<?, ?>, TableCell<?, ?>>() {
//                    @Override
//                    public TableCell call(final TableColumn<Patient, String> param) {
//                        final TableCell<Patient, String> cell = new TableCell<Patient, String>() {
//
//                            final Button btn = new Button("Del");
//
//                            @Override
//                            public void updateItem(String item, boolean empty) {
//                                super.updateItem(item, empty);
//                                if (empty) {
//                                    setGraphic(null);
//                                    setText(null);
//                                } else {
//                                    btn.setOnAction(event -> {
//                                        Person person =getTableView().getItems().get(getIndex());
//                                        data.remove(person);
//                                    });
//                                    setGraphic(btn);
//                                    setText(null);
//                                }
//                            }
//                        };
//                        return cell;
//                    }
//                };
//
//        cz.setCellFactory(DcellFactory);

        table11.setItems(patients);
    }

    @FXML
    void delete(){
        pl.getPatientList().remove(pa);//删除患者信息

        List<Doctor> list = getDoctor ();
        flag:for ( Doctor d: list){
            for ( Patient p: d.getPl().getPatientList( )){
                if (p.getMediId().equals(病历号.getText())){
                    d.getPl().getPatientList( ).remove(p);
                    break flag;
                }
            }
        }//修改医生信息

        s.addPatinentTo(pl);
        s.saveDoctor(list);//将修改信息保存

        姓名.setText("");
        id.setText("");
        Address.setText("");//清空

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("退号提示");
        alert.setContentText("退号成功");
        alert.showAndWait();//提示
    }

}