package View;

import Data.Patient;
import Department.GetDoctor;
import Department.Login;
import Department.Register;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;

import static javafx.fxml.FXMLLoader.load;


public class GhyController implements Initializable {
    @FXML
    private Button add;

    @FXML
    private Button reduce;

    @FXML
    private Button 退出1;

    @FXML
    private Button pay;

    @FXML
    private AnchorPane anchorpane;

//    @FXML
    private Parent root;
//    PrescribeDetails p=new PrescribeDetails();

    @FXML
    void add() {
        FXMLLoader loader = new FXMLLoader();
        try {
            loader.setLocation(getClass().getResource("/View/Guahao.fxml"));
            root = loader.load();
            anchorpane.getChildren().setAll(root);//把读取到的fxml加载到窗口上
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void pay() {
        FXMLLoader loader = new FXMLLoader();
        try {
            loader.setLocation(getClass().getResource("/View/Pay.fxml"));
            root = loader.load();
            anchorpane.getChildren().setAll(root);//把读取到的fxml加载到窗口上
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void withdraw() {
        FXMLLoader loader = new FXMLLoader();
        try {
            loader.setLocation(getClass().getResource("/View/Withdraw.fxml"));
            root = loader.load();
            anchorpane.getChildren().setAll(root);//把读取到的fxml加载到窗口上
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void out(){
        Stage sign = (Stage) 退出1.getScene().getWindow();
        Parent in = null;
        try {
            in = load(getClass().getResource("/View/Login.fxml"));
            Scene scene = new Scene(in, 986, 640);
            sign.setScene(scene);
            sign.show();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        add();
    }
}
