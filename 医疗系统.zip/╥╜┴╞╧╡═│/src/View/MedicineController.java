package View;

import Data.Medicine;
import Data.MedicineRecord;
import Data.Patient;
import Data.PatientList;
import Department.ReadFile;
import Department.Save;
import Department.Treat;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.ComboBoxListCell;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static javafx.fxml.FXMLLoader.load;

public class MedicineController extends ReadFile {

    @FXML
    private TableView<Medicine> medicineRecord;

    @FXML
    private ListView<MedicineRecord> 名称;

    @FXML
    private Button deleteMedicineRecord;

    @FXML
    private AnchorPane acpane2;

    @FXML
    private TableColumn<?, ?> medicineName;

    @FXML
    private TableColumn<?, ?> content;

    @FXML
    private TableColumn<?, ?> amount;

    @FXML
    private Button Prescribe;

    @FXML
    private TextField 门诊判断;

    @FXML
    private Button search;

    @FXML
    private Button addTemplate;

    @FXML
    private TableColumn<?, ?> price;

    @FXML
    private Button deleteTemplate;

    @FXML
    private TextField searchMedicine;

    @FXML
    void search(){
        searchMedicine.getText();
        getMedicineTemplate();

    }

    ObservableList<MedicineRecord> observableList = FXCollections.observableArrayList();

    //添加药方
    @FXML
    void add(){
        MedicineRecord mr = new MedicineRecord();
        mr.setName("默认处方");

        observableList.add(mr);

        名称.setItems(observableList);
        名称.setCellFactory(ComboBoxListCell.forListView(observableList));
    }

    //监听选中药方
    private void addListenner(){
        名称.getSelectionModel().selectedItemProperty().addListener(new NoticeListItemChangeListener());
    }

    Stage newStage = new Stage();
    AddMedicineController ac = new AddMedicineController();


    //给列表做监听
    private class NoticeListItemChangeListener implements ChangeListener<Object> {
        @Override
        public void changed(ObservableValue<?> observable, Object oldValue, Object newValue) {
            Parent in = null;
            FXMLLoader loader = new FXMLLoader();
            try {
                loader.setLocation(getClass().getResource("/View/AddMedicine.fxml"));
                in = loader.load();
                ac = loader.getController();
                newStage.setScene(new Scene(in,779,462));
                newStage.setTitle("东软云HIS系统");
                newStage.show();

                getmd((MedicineRecord)newValue);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    MedicineRecord md;
    void getmd(MedicineRecord d){
        md = d;
    }

    //删除处方
    @FXML
    void delete(){
        observableList.remove(md);
        newStage.close();

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("提示");
        alert.setContentText("该药方已删除");
        alert.showAndWait();

        名称.setItems(observableList);
        名称.setCellFactory(ComboBoxListCell.forListView(observableList));
    }

    ObservableList<Medicine> data2 = FXCollections.observableArrayList();

    //将所选药品信息放入列表中
    @FXML
    void addMedicineRecord() {
        for ( Medicine m : getMedicineList1() )
            data2.add(m);

            medicineName.setCellValueFactory(new PropertyValueFactory<>("chname"));
            price.setCellValueFactory(new PropertyValueFactory<>("price"));
            content.setCellValueFactory(new PropertyValueFactory<>("form"));

            medicineRecord.setItems(data2);
    }

//    List<Patient> pl = new ArrayList<>();
    @FXML
    void save(){
        Save s = new Save();
        s.saveMedicine(getMedicineList1());

        for ( Patient pp : getnullpatient()){
            for ( Patient patient : getPatient().getPatientList() ) {
                if (patient.getName().equals(pp.getName())) {
                    PatientList pl = getPatient();
                    pl.getPatientList().remove(patient);
                    pl.getPatientList().add(pp);
                    s.addPatinentTo(pl);
                }
            }
        }
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("提示");
        alert.setContentText("已为该患者开立药方");
        alert.showAndWait();
    }

    public void initialize() {
        addListenner();
    }
}
