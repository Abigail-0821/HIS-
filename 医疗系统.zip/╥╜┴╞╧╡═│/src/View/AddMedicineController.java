package View;

import Data.Medicine;
import Department.ReadFile;
import Department.Save;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;



public class AddMedicineController {
    @FXML
    private Button 查询;

    @FXML
    private TableColumn<?, ?> 药品编码;

    @FXML
    private TableColumn<?, ?> 单价;

    @FXML
    private Button 添加;

    @FXML
    private TableColumn<?, ?> 规格;

    @FXML
    private TableColumn<?, ?> 名称22;

    @FXML
    private TableView<Medicine> table;

    @FXML
    private TableColumn<?, ?> 类型;

    @FXML
    private TextField search22;

    public Button get查询() {
        return 查询;
    }

    public void initialize() {
        ReadFile rf = new ReadFile();
        ObservableList<Medicine> data = FXCollections.observableArrayList();
        data.addAll(rf.getMedicineList());

        药品编码.setCellValueFactory(new PropertyValueFactory<>("medicineId"));
        单价.setCellValueFactory(new PropertyValueFactory<>("price"));
        名称22.setCellValueFactory(new PropertyValueFactory<>("chname"));
        规格.setCellValueFactory(new PropertyValueFactory<>("form"));
        类型.setCellValueFactory(new PropertyValueFactory<>("type"));

        table.setItems(data);
        addListenner();
    }

    private void addListenner() {
        table.getSelectionModel().selectedItemProperty().addListener(new NoticeListItemChangeListener1());
    }

    Save s = new Save();
    List<Medicine> list = new ArrayList<>();
    private class NoticeListItemChangeListener1 implements ChangeListener<Object> {
        @Override
        public void changed(ObservableValue<?> observable, Object oldValue, Object newValue) {
            list.add((Medicine) newValue);
            s.saveMedicine(list);
        }
    }

    @FXML
    void add(ActionEvent event) {
        Stage stage = (Stage) 查询.getScene().getWindow();
        stage.close();
    }
}

//    boolean clicked = false;
//    void listen(){
//        查询.onKeyPressedProperty().addListener(new ChangeListener<EventHandler<? super KeyEvent>>() {
//            @Override
//            public void changed(ObservableValue<? extends EventHandler<? super KeyEvent>> observable, EventHandler<? super KeyEvent> oldValue, EventHandler<? super KeyEvent> newValue) {
//                clicked = true;
//            }
//        });
//    }
