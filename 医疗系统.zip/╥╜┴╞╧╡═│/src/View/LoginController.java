package View;

import Data.Doctor;
import Data.Ghy;
import Data.Patient;
import Department.Arrangement;
import Department.Login;
import Department.Register;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import static com.alibaba.fastjson.JSON.parseArray;
import static javafx.fxml.FXMLLoader.load;

public class LoginController extends Login implements Initializable {

    @FXML
    private ComboBox<String> choice;

    @FXML
    private PasswordField password;

    @FXML
    private Button 登录;

    @FXML
    private TextField name;

    @FXML
    private Font x1;

    @FXML
    private Button 清除账户;

    @FXML
    private Button 清除密码;

    @FXML
    private Insets x2;

    DoctorController dl=new DoctorController();

    @FXML
     void login() {
        Stage sign = (Stage) 登录.getScene().getWindow();
        Parent in;
//        try {
            if (choice.getValue().equals("挂号员")) {
                if (checkghy(name.getText(), password.getText())) {
                    try {
                        in = load(getClass().getResource("/View/Ghy.fxml"));
                        Scene scene = new Scene(in, 986, 640);
                        sign.setScene(scene);
                        sign.setTitle("东软云HIS系统");
                        sign.show();
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                } else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("登录提示");
                    alert.setHeaderText("登录错误");
                    alert.setContentText("您的帐号或密码有误");
                    alert.show();
                }
            } else if (choice.getValue().equals("医生")) {
                //登陆医生界面
                if (checkDoctor(name.getText(), password.getText())) {
                    FXMLLoader loader = new FXMLLoader();
                    try {
                        loader.setLocation(getClass().getResource("/View/Doctor.fxml"));

                        in = loader.load();
                        dl=loader.getController();

                        //把登录界面的医生信息传过去
                        dl.getLoginDoctor(name.getText());

                        Scene scene = new Scene(in, 986, 640);
                        sign.setScene(scene);
                        sign.setTitle("东软云HIS系统");
                        sign.show();
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                } else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("登录提示");
                    alert.setHeaderText("登录错误");
                    alert.setContentText("您的帐号或密码有误");
                    alert.show();
                }
            }else if (choice.getValue().equals("护士")) {
                if (checkfzy(name.getText(), password.getText())) {
                    try {
                        in = load(getClass().getResource("/View/Fzy.fxml"));
                        Scene scene = new Scene(in, 986, 640);
                        sign.setScene(scene);
                        sign.setTitle("东软云HIS系统");
                        sign.show();
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                } else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("登录提示");
                    alert.setHeaderText("登录错误");
                    alert.setContentText("您的帐号或密码有误");
                    alert.show();
                }
            }else if (choice.getValue().equals("管理员")) {
                Arrangement arrangement = new Arrangement();
                arrangement.arrangement();
                }
//        }catch(Exception ex){
//            Alert alert = new Alert(Alert.AlertType.ERROR);
//            alert.setTitle("提示");
//            alert.setContentText("请选择您的身份信息");
//            alert.showAndWait();
//        }
     }

    @FXML
    void id(){
        ObservableList<String> choices = FXCollections.observableArrayList("医生","挂号员","护士","管理员");
        choice.setItems(choices);
    }

    @FXML
    void pressButton1(ActionEvent event) {
        name.setText("");
    }

    @FXML
    void pressButton2(ActionEvent event) {
        password.setText("");
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }
}
