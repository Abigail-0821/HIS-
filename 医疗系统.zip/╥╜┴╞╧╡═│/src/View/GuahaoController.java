package View;

import Data.IllnessRecord;
import Data.MedicineRecord;
import Data.Patient;
import Data.PatientList;
import Department.GetDoctor;
import Department.ReadFile;
import Department.Register;
import Department.Save;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.*;


public class GuahaoController extends Register implements Initializable {
    @FXML
    private Button 挂号2;

    @FXML
    private RadioButton 病历本;

    @FXML
    private TextField 应收金额;

    @FXML
    private TextField Address;

    @FXML
    private TextField 发票号;

    @FXML
    private ComboBox<String> Doctor;

    @FXML
    private DatePicker Date;

    @FXML
    private TextField 姓名;

    @FXML
    private TextField 病历号;

    @FXML
    private ComboBox<String> 结算类别;

    @FXML
    private Button 清空2;

    @FXML
    private ComboBox<String> 收费方式;

    @FXML
    private TextField id;

    @FXML
    private ComboBox<String> 科室;

    @FXML
    private TextField age;

    @FXML
    private ComboBox<String> 号别;

    @FXML
    private ToggleGroup group;

    private void number(){
        ObservableList<String> choices = FXCollections.observableArrayList("普通号","专家号");
        号别.setItems(choices);
    }

    private void room(){
        ObservableList<String> choices = FXCollections.observableArrayList("内科","外科");
        科室.setItems(choices);
    }

    private void payWay(){
        ObservableList<String> choices = FXCollections.observableArrayList("现金","银行卡");
        收费方式.setItems(choices);
    }

    private void payKind(){
        ObservableList<String> choices = FXCollections.observableArrayList("自费","公费医疗");
        结算类别.setItems(choices);
    }

    @FXML
    void Doctor() {
        String department = 科室.getValue();
        GetDoctor gd = new GetDoctor();
        List ff = gd.getDoctor(department);//得到医生所在科室
        ObservableList<String> choices = FXCollections.observableArrayList(ff);
        Doctor.setItems(choices);//相应科室下的医生列表
    }

    @FXML
    void clearAll(){
        应收金额.setText("");
        发票号.setText("");
        姓名.setText("");
        age.setText("");
        id.setText("");
        Address.setText("");
        病历号.setText("");
        Date.setValue(null);
        结算类别.setValue("");
        号别.setValue("");
        科室.setValue("");
        收费方式.setValue("");
        Doctor.setValue("");
        病历本.setSelected(false);
    }

//    private List<Patient> patientList = new ArrayList<>();
//
//    public List<Patient> getPatientList() {
//        return patientList;
//    }

    @FXML
    void register()throws Exception{
        String sex = "";
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            java.util.Date birthDay = sdf.parse(Date.getValue().toString());
            int age1 = getAge(birthDay);
            age.setText(age1+"");

            RadioButton temp = (RadioButton) group.getSelectedToggle();
            if (temp.getText().equals("男"))
                sex = "男";
            else if (temp.getText().equals("女")) {
                sex = "女";
            }

            Patient p = new Patient(姓名.getText(),id.getText(),sex,age1,病历号.getText(),Address.getText(),new IllnessRecord(),new MedicineRecord());

            ReadFile rd = new ReadFile();

            boolean isfound = false;

            //检查病历号是否一样
                for (Patient l : rd.getPatient().getPatientList()){
                    if (l.getMediId().equals(病历号.getText())){
                        isfound = true;
                    }
                }
            //没有重复病历号
            if (!isfound){
                register(Doctor.getValue(),p);//把患者放入相应医生名下
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("挂号提示");
                alert.setContentText("挂号成功");
                alert.showAndWait();
            }else{
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("挂号提示");
                alert.setContentText("该病历号已注册");
                alert.show();
            }
        }catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("挂号提示");
            alert.setContentText("您填写的信息不全");
            alert.show();
        }
    }

    private void random(){
        int ran = (int)((Math.random()*9+1)*10000);
        发票号.setText(ran+"");
    }

    private void listener(){
        号别.getSelectionModel().selectedItemProperty().addListener(new myChangeListener<>());
        病历本.selectedProperty().addListener(new myChangeListener1<>());
    }

    private int value;

    private class myChangeListener<T> implements ChangeListener<T> {
        @Override
        public void changed(ObservableValue<? extends T> a, T old, T n) {
            value = 0;
            if (号别.getValue().equals("普通号")) {
                value = 35;
            }else if (号别.getValue().equals("专家号")){
                value = 50;
            }
            应收金额.setText(value + "");
        }
    }

    private class myChangeListener1<T> implements ChangeListener<T> {
        @Override
        public void changed(ObservableValue<? extends T> a, T old, T n) {
            if (病历本.isSelected()){
                value = value + 1;
            }
            应收金额.setText(value + "");
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        random();
        room();
        listener();
        payKind();
        payWay();
        number();
//        应收金额.textProperty().addListener(new ChangeListener<String>() {
//        @Override
//        public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
//            .setText("状态：当前字符数为：" + textField.getText().length());
//        }
//    });
    }
}
