package View;

import Data.Doctor;
import Data.DoctorList;
import Data.Patient;
import Department.*;
import com.alibaba.fastjson.JSON;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.ComboBoxListCell;
import javafx.scene.control.cell.TextFieldListCell;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Callback;
import javafx.util.StringConverter;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.lang.reflect.Array;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ResourceBundle;
import static javafx.fxml.FXMLLoader.load;

public class DoctorController extends ReadFile{

    @FXML
    private Button medicinelist;

    @FXML
    private TextField search;

    @FXML
    private ListView<Patient> patient;

    @FXML
    private AnchorPane acpane;

    @FXML
    private ListView<Patient> nullpatient;

    @FXML
    private Button 退出;

    @FXML
    private AnchorPane patientacpane;

    @FXML
    private Button reload;

    @FXML
    private AnchorPane listacpane;

    @FXML
    private TextField showchoosepatient;

    @FXML
    private Button illnesslist;

    @FXML
    private Button searchpatient;

    private Parent root;

    IllnessController p = new IllnessController();//控制器移动

    Save s = new Save();

//    Callback<ListView<Patient>, ListCell<Patient>> call;
//    {
//        call = TextFieldListCell.forListView(new StringConverter<Patient>() {
//            @Override
//            public String toString(Patient p) {
//                return p.getId() + "   " + p.getName() + "   " + p.getAge() + "   " + p.getSex();
//            }
//            @Override
//            public Patient fromString(String string) {
//                return new Patient();
//            }
//        });
//        nullpatient.setCellFactory(call);
//    }


    @FXML
    void illness() {
        FXMLLoader loader = new FXMLLoader();
        try {
            loader.setLocation(getClass().getResource("/View/Illness.fxml"));
            root = loader.load();
            acpane.getChildren().setAll(root);//把读取到的fxml加载到窗口上
            p = loader.getController();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void out(){
        Stage sign = (Stage) 退出.getScene().getWindow();//退出医生界面
        Parent in = null;
        try {
            in = load(getClass().getResource("/View/Login.fxml"));
            Scene scene = new Scene(in, 986, 640);
            sign.setScene(scene);
            sign.show();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    ObservableList<Patient> observableList = FXCollections.observableArrayList();
    ObservableList<Patient> observableList1 = FXCollections.observableArrayList();


    //把已挂号的患者信息放入列表
    private void showPatient(Doctor doctor){
        for ( Patient p : doctor.getPl().getPatientList() ) {
            for ( Patient pp : getnullpatient() )
                if (p.getMedicineRecord().getMedicines().isEmpty()||!p.getMediId().equals(pp.getMediId())) {
                    observableList.add(p);
                }else {
                    observableList1.add(p);
                }
        }

        //占位符 当listview没有数据时显示占位符
        nullpatient.setPlaceholder(new Label("没有数据"));//占位符 当listview没有数据时显示占位符
        nullpatient.setItems(observableList);
        nullpatient.setCellFactory(ComboBoxListCell.forListView(observableList1));

        patient.setPlaceholder(new Label("没有数据"));//占位符 当listview没有数据时显示占位符
        patient.setItems(observableList1);
        patient.setCellFactory(ComboBoxListCell.forListView(observableList1));
//        patientacpane.getChildren().addAll(nullpatient,listacpane);
    }

    //刷新患者列表
    @FXML
    void reload() {
        ObservableList<Patient> observableList3 = FXCollections.observableArrayList();
        List<Patient> list = d.getPl().getPatientList();
        List<Doctor> doctors = getDoctor();

        for ( Patient value : list ) {
            for ( Patient pp : getnullpatient() ) {
                Patient k = value;
                if (k.getMediId().equals(pp.getMediId())) {
                    list.remove(k);
                    observableList3.addAll(list);
                    observableList1.add(pp);
                }
            }
        }
        nullpatient.setItems(observableList3);

        patient.setItems(observableList1);
        patient.setCellFactory(ComboBoxListCell.forListView(observableList1));

        for ( Doctor doctor : doctors ) {
            if (doctor.getName().equals(d)) {
                doctor.getPl().setPatientList(list);
                s.saveDoctor(doctors);
            }
        }
    }

    //监听选中患者
    //保存医生名下患者的病历
    private void addListenner(){
        nullpatient.getSelectionModel().selectedItemProperty().addListener(new NoticeListItemChangeListener());
    }

    private List<Patient> nullpa = new ArrayList<>();
    private class NoticeListItemChangeListener implements ChangeListener<Object> {
        @Override
        public void changed(ObservableValue<?> observable, Object oldValue, Object newValue) {

            Treat treat = new Treat();
            treat.treat((Patient)newValue);

            nullpa.add((Patient)newValue);
            s.savenullpatien(nullpa);

            showchoosepatient.setText((Patient)newValue + "");

            //保存相关病人的病历信息

//            nullpatient.getItems().remove(newValue);//将诊断过的病人从列表中移除
//            patient.getItems().add((Patient)newValue);//将诊断过的病人添加到列表中
        }
    }

    Doctor d ;
    void getLoginDoctor(String p){
        for ( Doctor doc : getDoctor() ) {
            if (doc.getName().equals(p)) {
                initialize(doc);
                d = doc;
            }
        }
    }

    private void initialize(Doctor loginDoctor) {
        showPatient(loginDoctor);
        illness();
        addListenner();
    }

    @FXML
    void medicineList(ActionEvent event) {
        p.medicine();
    }

}
