package View;

import Data.DiseaseType;
import Department.ReadFile;
import Department.Treat;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;

import java.io.IOException;

public class IllnessController extends ReadFile {

    @FXML
    private TextField 过敏史;

    @FXML
    private TextField 注意事项;

    @FXML
    private Button 增加判断;

    @FXML
    private TableView<DiseaseType> disease;

    @FXML
    private TextField 主诉;

    @FXML
    private TableColumn<?, ?> ICD;

    @FXML
    private AnchorPane acpane2;

    @FXML
    private TextField 现病治疗情况;

    @FXML
    private TextField 体格检查;

    @FXML
    private TabPane tabpane;

    @FXML
    private TextField 检查建议;

    @FXML
    private Button 提交;

    @FXML
    private TableColumn<?, ?> name;

    @FXML
    private Tab medicinepane;

    @FXML
    private Button 暂存;

    @FXML
    private TableColumn<?, ?> time;

    @FXML
    private TextField 现病史;

    @FXML
    private TextField 既往史;

    @FXML
    private Button 删除判断;

    private Parent root;

    void add() {
        FXMLLoader loader = new FXMLLoader();
        try {
            loader.setLocation(getClass().getResource("/View/Medicine.fxml"));
            root = loader.load();
            acpane2.getChildren().setAll(root);//把读取到的fxml加载到窗口上
        } catch (IOException e) {
            e.printStackTrace();
        }
//
//        ObservableList<Disease> data = FXCollections.observableArrayList();
//        data.addAll(getDisease());
//
//        ICD.setCellValueFactory(new PropertyValueFactory<>("ICDNumber"));
//        name.setCellValueFactory(new PropertyValueFactory<>("name"));
//
//        disease.setItems(data);

    }

    @FXML
    void medicine(){
        tabpane.getSelectionModel().select(medicinepane);
    }//选中开药页面

    //保存到文件
    @FXML
    void addIll(){
        Treat t = new Treat();
        t.save(主诉.getText(),现病史.getText(),现病治疗情况.getText(),既往史.getText(),过敏史.getText(),体格检查.getText(),检查建议.getText(),注意事项.getText());
    }

    @FXML
    void add1(){
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("诊断提示");
        alert.setContentText("病历已提交");
        alert.show();
    }
    public void initialize() {
        add();
    }
}
