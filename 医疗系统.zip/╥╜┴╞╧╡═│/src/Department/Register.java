package Department;

import Data.*;
import java.text.SimpleDateFormat;
import java.util.*;

public abstract class Register{
    public int getAge(Date birthDay) throws Exception {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        Calendar cal = Calendar.getInstance();

        int yearNow = cal.get(Calendar.YEAR);
        int monthNow = cal.get(Calendar.MONTH);
        int dayOfMonthNow = cal.get(Calendar.DAY_OF_MONTH);
        cal.setTime(birthDay);

        int yearBirth = cal.get(Calendar.YEAR);
        int monthBirth = cal.get(Calendar.MONTH);
        int dayOfMonthBirth = cal.get(Calendar.DAY_OF_MONTH);

        int age = yearNow - yearBirth;

        if (monthNow <= monthBirth) {
            if (monthNow == monthBirth) {
                if (dayOfMonthNow < dayOfMonthBirth) age--;
            } else {
                age--;
            }
        }
        return age;
    }

//    //中转信息。把登录界面的医生传过去
//    public Doctor getLoginDoctor() {
//        Doctor doc = new Doctor();
//        LoginController lc = new LoginController();
//        for ( Doctor doctor : doctors) {
//            if (doctor.getName().equals(lc.getLoginDoctor())) {
//                doc = doctor;
//            }
//        }return doc;
//    }

    private Save save = new Save();
    private ReadFile rd = new ReadFile();
    PatientList pl = rd.getPatient();

    //把对应患者的加入所属医生的患者列表中
    //把患者放入相应医生名下
    public void register(String d, Patient p) {
        ReadFile rf = new ReadFile();
        List<Doctor> doctors = rf.getDoctor();
        for ( Doctor doctor : doctors ) {
            if (doctor.getName().equals(d)) {
                doctor.getPl().getPatientList().add(p);
                save.saveDoctor(doctors);
                pl.getPatientList().add(p);//把患者信息存入文件
                save.addPatinentTo(pl);
            }
        }
    }
}