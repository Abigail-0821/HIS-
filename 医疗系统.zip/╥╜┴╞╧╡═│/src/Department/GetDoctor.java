package Department;

import Data.Doctor;
import Data.DoctorList;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class GetDoctor{
    public List<String> getDoctor(String keshi) {
       ReadFile rf = new ReadFile();
        List<Doctor> doctors = rf.getDoctor();//得到医生的列表
        List<String> names = new ArrayList<>();//存放医生的名字
        for( Doctor d: doctors ){
            if (d.getKeshi().equals(keshi)) {
                names.add(d.getName());
            }
        }return names;
    }
}
