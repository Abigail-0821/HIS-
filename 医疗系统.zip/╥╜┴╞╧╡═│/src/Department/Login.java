package Department;

import Data.Doctor;
import Data.DoctorList;
import Data.Fzy;
import Data.Ghy;
import java.util.ArrayList;
import java.util.List;

public abstract class Login {

    ReadFile rf = new ReadFile();

    public boolean checkghy(String name, String password) {
        return name.equals(Ghy.getName()) && password.equals(Ghy.getPassword());
    }

    public boolean checkDoctor(String name,String password){
        List<Doctor> doctors = rf.getDoctor();
        for ( Doctor p : doctors) {
                if (name.equals(p.getName()) && password.equals(p.getPassword())) {
                    return true;
                }
        }return false;
    }

    public boolean checkfzy(String name, String password) {
        return name.equals(Fzy.getName()) && password.equals(Fzy.getPassword());
    }
}
