package Department;

import Data.Patient;

public abstract class Prescription extends Treat{
    //把药房存入医生看过的病人中
    public void prescription(Patient p){


    }
}
