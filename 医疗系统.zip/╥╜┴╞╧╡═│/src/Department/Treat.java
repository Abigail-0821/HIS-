package Department;

import Data.Doctor;
import Data.IllnessRecord;
import Data.Patient;
import Data.PatientList;
import View.IllnessController;

import java.util.List;

public class Treat extends ReadFile {
    //保存病历信息

    Patient p = new Patient();
    Save s = new Save();

    public void treat(Patient pp) {
        p = pp;
    }

    public void save(String a, String b, String c, String d, String e, String f, String g, String h) {
        IllnessRecord md = new IllnessRecord();
        md.set主诉(a);
        md.set现病史(b);
        md.set现病治疗情况(c);
        md.set既往史(d);
        md.set过敏史(e);
        md.set体格检查(f);
        md.set检查建议(g);
        md.set注意事项(h);
        p.setIllnessRecord(md);

        PatientList pl = getPatient();
        List<Patient> list = pl.getPatientList();

        for ( Patient patient : list ) {
            if (patient.getName().equals(p.getName())) {
                list.remove(patient);
                list.add(p);
                s.addPatinentTo(pl);
            }
        }
    }
}
