package Department;

public class Pay {
}
