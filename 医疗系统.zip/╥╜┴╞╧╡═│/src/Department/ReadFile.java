package Department;

import Data.*;
import com.alibaba.fastjson.JSON;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

public class ReadFile {
    //读取文件中医生信息
    public List<Doctor> getDoctor() {
        String s = "";
        try {
            FileReader r = new FileReader("C:\\Users\\渡青\\IdeaProjects\\医疗系统\\src\\医生信息.txt");
            BufferedReader br = new BufferedReader(r);
            s=br.readLine();;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return JSON.parseArray(s,Doctor.class);
    }

    //读取文件中患者信息
    public PatientList getPatient(){
        String s = null;
        try {
            FileReader r = new FileReader("C:\\Users\\渡青\\IdeaProjects\\医疗系统\\src\\患者信息.txt");
            BufferedReader br = new BufferedReader(r);
            s = br.readLine();
        } catch (IOException  e) {
            e.printStackTrace();
        }
        return JSON.parseObject(s, PatientList.class);
    }

    //读取文件中药品模板
    public MedicineTemplate getMedicineTemplate(){
        String s = null;
        try {
            FileReader r = new FileReader("C:\\Users\\渡青\\IdeaProjects\\医疗系统\\src\\药品模板.txt");
            BufferedReader br = new BufferedReader(r);
            s = br.readLine();
        } catch (IOException  e) {
            e.printStackTrace();
        }
        return JSON.parseObject(s, MedicineTemplate.class);
    }

    //读取文件中药品
    public List<Medicine> getMedicineList(){
        String s = null;
        try {
            FileReader r = new FileReader("C:\\Users\\渡青\\IdeaProjects\\医疗系统\\src\\药品.txt");
            BufferedReader br = new BufferedReader(r);
            s = br.readLine();
        } catch (IOException  e) {
            e.printStackTrace();
        }
        return JSON.parseArray(s, Medicine.class);
    }

    //读取文件中开药药品
    public List<Medicine> getMedicineList1(){
        String s = null;
        try {
            FileReader r = new FileReader("C:\\Users\\渡青\\IdeaProjects\\医疗系统\\src\\开药信息.txt");
            BufferedReader br = new BufferedReader(r);
            s = br.readLine();
        } catch (IOException  e) {
            e.printStackTrace();
        }
        return JSON.parseArray(s, Medicine.class);
    }
//
//读取文件中开药药品
    public List<Patient> getnullpatient(){
        String s = null;
        try {
            FileReader r = new FileReader("C:\\Users\\渡青\\IdeaProjects\\医疗系统\\src\\开药患者信息.txt");
            BufferedReader br = new BufferedReader(r);
            s = br.readLine();
        } catch (IOException  e) {
            e.printStackTrace();
        }
        return JSON.parseArray(s, Patient.class);
    }

    //读取文件中的疾病
    public List<DiseaseType> getDisease(){
        String s = null;
        try {
            FileReader r = new FileReader("C:\\Users\\渡青\\IdeaProjects\\医疗系统\\src\\疾病.txt");
            BufferedReader br = new BufferedReader(r);
            s = br.readLine();
            System.out.println(s);
        } catch (IOException  e) {
            e.printStackTrace();
        }
        return JSON.parseObject(s,List.class);
    }
}
