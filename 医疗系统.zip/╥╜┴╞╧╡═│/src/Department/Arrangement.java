package Department;

import Data.DiseaseType;

import java.util.Scanner;

public class Arrangement {
    Scanner sc = new Scanner(System.in);
    DiseaseType root = new DiseaseType();
    String son;
    String father


    public void arrangement(){
        System.out.println("请选择操作");
        System.out.println("1.创建树");
        System.out.println("2.查询树");
        System.out.println("3.查询病种下的病人");
        int choice = sc.nextInt();
        int i = 0;

        if (choice==1){
            System.out.println("请输入节点名称，父节点名称（逗号分隔），如果是根节点，不需要输入父节点名称");
            while (!sc.next().equals("exit")) {
                String input = sc.next();
                String[] input1 = input.split(",");

                if (input.length() == 1) {
                   root.setName(input1[0]);
                    root.setICDNumber(i+"");
                } else {
                    i++;
                    son = input1[0];
                    father = input1[1];
                    DiseaseType dt = new DiseaseType(son);
                    dt.setICDNumber(i+"");
                    findFather(root);

                }



            }

        }else if (choice==2){

        }else if (choice==3){
            System.out.println("请输入病种名称");
            String illness = sc.next();
        }
    }

    public String findFather(DiseaseType d){
        for (DiseaseType dd: d.getSub_diseases()){
            if (dd.getName().equals(son)){
                return dd.getName();
            }else {
                findFather(dd.getICDNumber()+)
            }
        }

    }


}
