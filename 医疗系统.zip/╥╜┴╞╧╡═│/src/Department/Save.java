package Department;

import Data.Doctor;
import Data.Medicine;
import Data.Patient;
import Data.PatientList;
import com.alibaba.fastjson.JSON;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Save{

    public void addPatinentTo(PatientList pl){
        String s = JSON.toJSONString(pl);//将挂号后的患者信息转换为JSON
        try {
            File f = new File("C:\\Users\\渡青\\IdeaProjects\\医疗系统\\src\\患者信息.txt");
            FileWriter fw=new FileWriter(f);
            PrintWriter bw=new PrintWriter(fw);
            bw.println(s);
            bw.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void saveDoctor(List<Doctor> list){
        String s = JSON.toJSONString(list);//将挂号后的医生信息转换为JSON
        try {
            File f = new File("C:\\Users\\渡青\\IdeaProjects\\医疗系统\\src\\医生信息.txt");
            FileWriter fw=new FileWriter(f);
            PrintWriter bw=new PrintWriter(fw);
            bw.println(s);
            bw.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void saveMedicine(List<Medicine> list){
        String s = JSON.toJSONString(list);//将挂号后的医生信息转换为JSON
        try {
            File f = new File("C:\\Users\\渡青\\IdeaProjects\\医疗系统\\src\\开药信息.txt");
            FileWriter fw=new FileWriter(f);
            PrintWriter bw=new PrintWriter(fw);
            bw.println(s);
            bw.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void savenullpatien(List<Patient> list){
        String s = JSON.toJSONString(list);//将挂号后的医生信息转换为JSON
        try {
            File f = new File("C:\\Users\\渡青\\IdeaProjects\\医疗系统\\src\\开药患者信息.txt");
            FileWriter fw=new FileWriter(f);
            PrintWriter bw=new PrintWriter(fw);
            bw.println(s);
            bw.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}