package Department;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;


public class HospitalSystem extends Application {
    @Override
    public void start(Stage primaryStage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/View/Login.fxml"));
        primaryStage.setTitle("云医院登录系统");
        primaryStage.setScene(new Scene(root,986,640));
        primaryStage.show();
    }

//    public void gotomain(){
//        Stage primaryStage=(Stage)stage.getScene().getWindow();//将submit(登录按钮)与Main类中的primaryStage(新窗口)绑定 并执行close()
//        primaryStage.close();//打开新的窗口 所以要关闭当前的窗口
//        //mStage.close();
//         we=new WelcomeMain();//新窗口类
//        Stage stage=new Stage();
//        we.start(stage);//打开新窗口
//}

    public static void main(String[] args) {
        launch(args);
    }
}